<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Pengaduan IT BPS') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    @vite(['resources/css/app.css', 'resources/js/app.js'])

</head>

<body class="font-sans antialiased bg-gray-100">

<div class="flex min-h-screen">

    {{-- ================= SIDEBAR ================= --}}
    <aside class="w-64 bg-gray-900 text-white flex flex-col">

        <div class="p-5 text-lg font-bold border-b border-gray-700">
            Pengaduan IT BPS
        </div>

        <nav class="p-4 space-y-2 flex-1">

            @auth

            {{-- ADMIN --}}
            @if(auth()->user()->role === 'admin')

                <a href="{{ route('admin.dashboard') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Dashboard Admin
                </a>

                <a href="{{ route('admin.laporan') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Verifikasi Laporan
                </a>

                <a href="{{ route('admin.activity-log') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Activity Log
                </a>

            @endif


            {{-- KASUBAG --}}
            @if(auth()->user()->role === 'kasubag')

                <a href="{{ route('kasubag.dashboard') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Dashboard Kasubag
                </a>

            @endif


            {{-- PEGAWAI --}}
            @if(auth()->user()->role === 'pegawai')

                <a href="{{ route('pegawai.dashboard') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Dashboard Pegawai
                </a>

                <a href="{{ route('pegawai.lapor.create') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Buat Laporan
                </a>

                <a href="{{ route('pegawai.laporan_saya') }}"
                   class="block p-2 rounded hover:bg-gray-700">
                    Laporan Saya
                </a>

            @endif

            @endauth

        </nav>


        {{-- ================= USER AREA ================= --}}
        @auth
        <div class="border-t border-gray-700 p-4">

            <div class="mb-3">
                <p class="font-semibold">
                    {{ auth()->user()->name }}
                </p>

                <p class="text-xs text-gray-400 uppercase">
                    {{ auth()->user()->role }}
                </p>
            </div>

            <a href="{{ route('profile.edit') }}"
               class="block mb-2 text-sm hover:text-gray-300">
                👤 Profile
            </a>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button
                    type="submit"
                    class="w-full text-left text-sm text-red-400 hover:text-red-300">
                    🚪 Logout
                </button>
            </form>

        </div>
        @endauth

    </aside>


    {{-- ================= MAIN CONTENT ================= --}}
    <main class="flex-1 p-6">
        {{ $slot }}
    </main>

</div>

</body>
</html>